# verify-client
Web Client for the "Verify" document verification system
